/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package serverapp;

import java.util.StringTokenizer;

/**
 *
 * @author André
 */
public class DeviceLib {

    public DeviceLib() {
        //AULA 3 - inicializar as lib
    }

    protected String callHardware(String content) {
        String reply = null;
        StringTokenizer st = new StringTokenizer(content, utilities.constants.token);
        String operation = st.nextToken();
        switch(operation)
        {
            case "state":
                int state;
                //chamar método state e colocar na variavel state
                reply = "" + state;
                break;
            case "on":
                //chamar método para ligar o dispositivo
                reply = "Turned ON";
                break;
            case "off":
                //chamar método para ligar o dispositivo
                reply = "Turned OFF";
                break;
            case "location":
                int latitude;
                int longitude;
                //chamar método localização e colocar a latitude e longitude nas variaveis respectivas
                StringBuilder sb = new StringBuilder();
                sb.append(latitude);
                sb.append("#");
                sb.append(longitude);
                sb.append("#");
                reply = sb.toString();
                break;
            case "value":
                int value;
                //chamar método value e colocar na variavel value
                reply = "" + value;
                break;
            case "error":
                int error;
                //chamar método error e colocar na variavel error
                reply = "" + error;
                break;
        }
        return reply;
    }
}
