/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package utilities;

/**
 *
 * @author André
 */
public class constants {
    
    public static String token = "#";
    
}
